export default {
  axiosInitConfig: {},
  formatResponse(res) {
    return res;
  },
  feedBack() {},
  startRequest() {},
  finishRequest() {},
}
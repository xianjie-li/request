export default {
  cjs: 'rollup',
  esm: 'rollup',
}
